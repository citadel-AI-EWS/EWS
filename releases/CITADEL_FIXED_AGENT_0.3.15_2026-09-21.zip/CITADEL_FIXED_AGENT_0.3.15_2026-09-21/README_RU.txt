CITADEL/EWS — исправленный самодостаточный пакет 0.3.15

1. Распакуйте ZIP полностью.
2. Запустите START_HERE.cmd.
3. Агент использует HTTPS Controller: https://citadel-ai.init1.workers.dev

Исправлено в этом пакете:
- JSON с UTF-8 BOM больше не ломает загрузку конфигурации.
- При каждом запуске агент один раз сверяет node_id с Controller по Ed25519 public key; старый локальный ID автоматически исправляется.
- localhost / 127.0.0.1 / ::1 согласованы для локального HTTP-теста.
- Агент определяет текущий LAN/network IPv4; адреса не зашиты в код и могут меняться по DHCP.
- LAN/network/MAC входят в system_inventory и heartbeat; Controller использует их для диагностики и ограниченного Wake-on-LAN.
- Core Agent устанавливается как Windows Service CitadelEWSNode под LocalService с Automatic (Delayed Start).
- Read-only Enterprise Probe собирает CIM/Perf, Event Log, Windows Update, Hyper-V, domain/GPO, MDM/Intune и service-identity status без remote shell.
- Старый Startup shortcut удаляется; существующая node identity мигрирует в ProgramData и сохраняется.
- setup_windows.ps1 -Uninstall выполняет явное удаление; -PreserveState сохраняет node state по запросу.
- В архиве находятся agent-файлы, проверяемый CitadelNodeService.cs и windows_service.ps1: установка не скачивает Python-код из GitHub.

Произвольный SSH shell в пакет не включён. Разрешены только подписанные allowlist-команды Controller, включая reboot/shutdown и ограниченный wake_peer без shell.
