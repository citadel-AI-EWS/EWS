CITADEL/EWS — Windows compatibility release 0.3.11-wincompat.1

1. Распакуйте ZIP полностью.
2. Запустите START_HERE.cmd.
3. Агент использует HTTPS Controller: https://citadel-ai.init1.workers.dev

Исправлено в этом пакете:
- winget больше не является обязательным: при его отсутствии/ошибке используется официальный Python 3.13.15 с проверкой SHA-256.
- Поддержана 32-битная Windows 10: installer выбирает x86 Python и отдельный набор готовых win32 wheels.
- На Windows зависимости ставятся только из бинарных wheels; локальная сборка C/Rust пакетов не запускается.
- JSON с UTF-8 BOM больше не ломает загрузку конфигурации.
- При каждом запуске агент один раз сверяет node_id с Controller по Ed25519 public key; старый локальный ID автоматически исправляется.
- localhost / 127.0.0.1 / ::1 согласованы для локального HTTP-теста.
- Агент сам определяет текущий LAN IPv4 и Tailscale IPv4; адреса не зашиты в код и могут меняться по DHCP.
- LAN/Tailscale/MAC входят в system_inventory и heartbeat; Controller использует их для диагностики и ограниченного Wake-on-LAN.
- В архиве находятся сами agent-файлы: установка не скачивает Python-код из GitHub.

Произвольный SSH shell в пакет не включён. Разрешены только подписанные allowlist-команды Controller, включая reboot/shutdown и ограниченный wake_peer без shell.
