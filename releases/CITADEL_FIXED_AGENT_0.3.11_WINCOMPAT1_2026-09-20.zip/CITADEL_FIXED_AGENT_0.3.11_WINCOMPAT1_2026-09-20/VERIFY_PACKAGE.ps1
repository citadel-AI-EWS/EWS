[CmdletBinding()]
param()
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Manifest = Join-Path $Root "SHA256SUMS.txt"
if (-not (Test-Path -LiteralPath $Manifest)) { throw "SHA256SUMS.txt not found" }
foreach ($line in Get-Content -LiteralPath $Manifest) {
  if ([string]::IsNullOrWhiteSpace($line)) { continue }
  $parts = $line -split "  ", 2
  if ($parts.Count -ne 2) { throw "Invalid manifest line: $line" }
  $expected = $parts[0].Trim().ToLowerInvariant()
  $name = $parts[1].Trim()
  $path = Join-Path $Root $name
  if (-not (Test-Path -LiteralPath $path)) { throw "Missing file: $name" }
  $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -ne $expected) { throw "Hash mismatch: $name" }
}
Write-Host "CITADEL package integrity: OK"
