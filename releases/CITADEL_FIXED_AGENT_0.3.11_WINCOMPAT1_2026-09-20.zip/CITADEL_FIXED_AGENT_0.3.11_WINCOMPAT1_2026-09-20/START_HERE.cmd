@echo off
setlocal
call "%~dp0Install Windows Node.cmd" %*
